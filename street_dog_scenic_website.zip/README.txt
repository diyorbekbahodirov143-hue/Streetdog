STREET DOG — scenic website concept

FILES
- index.html: responsive website with all CSS and JavaScript embedded
- assets/: required local photos and visual assets (32 WEBP files)

HOW TO OPEN
1. Keep index.html and assets/ in the same directory.
2. Open index.html in any modern browser.

HOW TO PUBLISH ON GITHUB PAGES
1. Create a PUBLIC GitHub repository (or use your existing repository).
2. Upload index.html AND the assets folder to the repository root.
3. GitHub > Settings > Pages > Deploy from branch > main / (root).
4. Wait for GitHub Pages to deploy and visit the URL it provides.

FEATURES
- Scenic restaurant photo backgrounds, premium product spotlight
- All 27 menu entries and AI-recreated food pictures from supplied materials
- Menu categories, text search, option/size select
- Add-to-cart with persistence, quantity controls, totals
- Copy order text, branch phone links and Instagram
- Mobile-friendly responsive layout and compact phone navigation

IMPORTANT
- This is a demonstration concept, not an authorized official STREET DOG website.
- The food and restaurant backgrounds are AI-generated recreations, not documentary photographs.
- Prices are transcribed from the user-supplied menu screenshot. Verify with the restaurant before publication.
- The cart does NOT submit an order. Phone/copy order workflow only. Telegram/online checkout requires backend setup.
- Google Fonts improve styling when online; built-in fallback fonts work offline.
